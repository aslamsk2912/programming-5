/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
        printf("\nsizeof(12)=%d",sizeof(12));
    printf("\nsizeof('b')=%d",sizeof('b'));
    printf("\nsizeof(12.6)=%d",sizeof(12.6));
    printf("\nsizeof(12.6f)=%d",sizeof(12.6f));
    return 0;
}