/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x=100,y=200;
    if((x-=100)&&(y-=100))
    printf("x=%d and y=%d",x,y);
    else
    printf("x=%d and y=%d",x,y);
    

    return 0;
}
